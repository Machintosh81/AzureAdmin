# Demo Node & Express Docker App

> This is a bare bones Node & Express app for Docker demos.

## App Info

This is a Node and Express web application built to run in a Docker container. I use it for demos with Docker.

### Author

Mike Pfeiffer
[@mike_pfeiffer](https://twitter.com/mike_pfeiffer)

### Version

1.0.0

### License

This project is licensed under the Apache License 2.0